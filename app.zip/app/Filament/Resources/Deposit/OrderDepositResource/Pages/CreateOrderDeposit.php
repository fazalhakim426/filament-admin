<?php

namespace App\Filament\Resources\Deposit\OrderDepositResource\Pages;

use App\Filament\Resources\Deposit\OrderDepositResource;
use Filament\Actions;
use Filament\Resources\Pages\CreateRecord;

class CreateOrderDeposit extends CreateRecord
{
    protected static string $resource = OrderDepositResource::class;
}
