<?php

namespace App\Filament\Resources\Shop\SupplierResource\Pages;

use App\Filament\Resources\Shop\SupplierResource;
use Filament\Resources\Pages\CreateRecord;

class CreateSupplier extends CreateRecord
{
    protected static string $resource = SupplierResource::class;
}
