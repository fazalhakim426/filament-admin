<?php

namespace App\Filament\Resources\Deposit\AllDepositResource\Pages;

use App\Filament\Resources\Deposit\AllDepositResource;
use Filament\Actions;
use Filament\Resources\Pages\CreateRecord;

class CreateAllDeposit extends CreateRecord
{
    protected static string $resource = AllDepositResource::class;
}
