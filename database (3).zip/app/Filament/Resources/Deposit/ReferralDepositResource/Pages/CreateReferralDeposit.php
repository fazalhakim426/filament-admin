<?php

namespace App\Filament\Resources\Deposit\ReferralDepositResource\Pages;

use App\Filament\Resources\Deposit\ReferralDepositResource;
use Filament\Actions;
use Filament\Resources\Pages\CreateRecord;

class CreateReferralDeposit extends CreateRecord
{
    protected static string $resource = ReferralDepositResource::class;
}
